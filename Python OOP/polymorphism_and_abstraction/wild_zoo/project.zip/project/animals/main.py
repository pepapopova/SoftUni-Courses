from project.animals.mammals import Tiger
from project.food import Vegetable, Fruit, Meat

tiger = Tiger("Johny", 10, 'dessert')
veg = Vegetable(3)
fruit = Fruit(5)
meat = Meat(1)
print(tiger)
# print(hen.make_sound())
# hen.feed(veg)
# hen.feed(fruit)
# hen.feed(meat)
# print(hen)
